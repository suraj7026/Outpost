"""Durable, root-owned native host installation. Never edits Kubernetes or legacy data."""
from __future__ import annotations

import base64
import fcntl
import hashlib
import json
import os
import platform
import pwd
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path

PREFIX = Path('/opt/outpost-native')
DATA = Path('/var/lib/outpost-native')
CONFIG = Path('/etc/outpost-native')
OPERATIONS = Path('/var/lib/outpost-setup/operations')
UNIT_DIRECTORY = Path('/etc/systemd/system')
UNITS = ('outpost-native-worker.service', 'outpost-native-coordinator.service')
STAGES = ('Preflight', 'Service accounts', 'Private Node runtime', 'Locked server dependencies',
          'Browser runtime', 'Protected configuration', 'Device enrollment', 'Persistent services',
          'Health verification', 'Server ready', 'Private connection', 'Authenticated registration')


def atomic_json(path: Path, value: object, mode: int = 0o600) -> None:
    """Persist a complete receipt before publishing the next stage."""
    temporary = path.with_name(path.name + '.tmp')
    with os.fdopen(os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, mode), 'w') as target:
        json.dump(value, target, separators=(',', ':'))
        target.flush()
        os.fsync(target.fileno())
    os.chmod(temporary, mode)
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def validate_request(value: dict) -> dict:
    """Accept only this installation protocol; no arbitrary paths, ports or commands."""
    required = {'operationId', 'environmentId', 'deviceId', 'publicKey', 'label', 'releaseId', 'sha256', 'size', 'browser', 'coexistence'}
    if set(value) != required:
        raise ValueError('Invalid installation request fields')
    for key in ('operationId', 'environmentId', 'deviceId'):
        if str(uuid.UUID(value[key])) != value[key]:
            raise ValueError('Invalid installation identity')
    if not re.fullmatch(r'host-[a-f0-9]{20}', value['releaseId']) or not re.fullmatch(r'[a-f0-9]{64}', value['sha256']):
        raise ValueError('Invalid release digest')
    if type(value['size']) is not int or not 0 < value['size'] <= 16 * 1024 * 1024:
        raise ValueError('Release size exceeds limit')
    if type(value['browser']) is not bool or type(value['coexistence']) is not bool:
        raise ValueError('Explicit installation choices required')
    if not isinstance(value['label'], str) or not 1 <= len(value['label']) <= 80 or any(ord(c) < 32 or ord(c) == 127 for c in value['label']):
        raise ValueError('Invalid environment label')
    if len(base64.b64decode(value['publicKey'], validate=True)) != 32:
        raise ValueError('Invalid device public key')
    return value


def extract_source(archive: Path, destination: Path) -> None:
    """Extract only bounded regular source files under a newly created directory."""
    with tarfile.open(archive) as source:
        members = source.getmembers()
        if len(members) > 4096 or sum(item.size for item in members) > 32 * 1024 * 1024:
            raise ValueError('Release exceeds extraction limits')
        for item in members:
            if not (item.isfile() or item.isdir()) or item.name.startswith('/') or '..' in Path(item.name).parts:
                raise ValueError('Unsafe release member')
        source.extractall(destination, members=members, filter='data')


def bootstrap() -> None:
    """Read the reviewed packet over SSH, persist it and start one root-owned job."""
    if os.geteuid() != 0 or sys.version_info < (3, 12):
        raise RuntimeError('Administrative setup requires root and Python 3.12 or later')
    request = validate_request(json.loads(sys.stdin.buffer.readline(16385)))
    payload = sys.stdin.buffer.read(request['size'] + 1)
    if len(payload) != request['size'] or hashlib.sha256(payload).hexdigest() != request['sha256']:
        raise ValueError('Release transfer checksum mismatch')
    OPERATIONS.mkdir(parents=True, mode=0o711, exist_ok=True)
    os.chmod(OPERATIONS.parent, 0o711)
    os.chmod(OPERATIONS, 0o711)
    operation = OPERATIONS / request['operationId']
    try:
        operation.mkdir(mode=0o711)
    except FileExistsError:
        if json.loads((operation / 'request.json').read_text()) != request:
            raise ValueError('Operation identity already belongs to a different request')
        print((operation / 'status.json').read_text())
        return  # A repeated launch can only read its existing receipt, never execute again.
    operation.chmod(0o711)
    atomic_json(operation / 'request.json', request)
    (operation / 'release.tar.gz').write_bytes(payload)
    (operation / 'cancel').touch(mode=0o600)
    os.chown(operation / 'cancel', int(os.environ.get('SUDO_UID', '0')), -1)
    source = operation / 'source'
    source.mkdir(mode=0o755)
    extract_source(operation / 'release.tar.gz', source)
    status = {'operationId': request['operationId'], 'environmentId': request['environmentId'], 'releaseId': request['releaseId'],
              'state': 'queued', 'completedSteps': 0, 'totalSteps': len(STAGES), 'stage': STAGES[0],
              'startedAt': int(time.time() * 1000), 'updatedAt': int(time.time() * 1000), 'log': ['Verified release received. Installation queued.'], 'error': None}
    atomic_json(operation / 'status.json', status, 0o644)
    command = ['/usr/bin/systemd-run', '--unit=outpost-setup-' + request['operationId'],
               '--property=Type=exec', '--property=RuntimeMaxSec=2700', '--property=KillMode=control-group',
               '--property=UMask=0077', '/usr/bin/python3', str(source / 'deploy/environment/host_install.py'), '--run', str(operation)]
    launch_log = operation / 'launch.log'
    descriptor = os.open(launch_log, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as output:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=output, stderr=output, check=False, timeout=20)
    atomic_json(operation / 'launch.json', {'returnCode': result.returncode}, 0o644)
    if result.returncode:
        status.update(state='unknown', error=f'Setup service launch was not confirmed (exit {result.returncode}). Check status; an administrator can inspect launch.log. Do not assume no steps ran.')
    print(json.dumps(status))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never forward internal service authentication to another listener or origin."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        """Reject all redirects, including loopback ones."""
        return


class Installer:
    """One serialized install, with bounded commands and non-secret stage receipts."""

    def __init__(self, operation: Path) -> None:
        self.operation = operation
        self.request = validate_request(json.loads((operation / 'request.json').read_text()))
        self.status = json.loads((operation / 'status.json').read_text())
        self.release = PREFIX / 'releases' / self.request['releaseId']
        self.node = self.release / 'node/bin/node'
        self.environment = {'PATH': str(self.release / 'node/bin') + ':/usr/sbin:/usr/bin:/sbin:/bin',
                            'HOME': str(operation / 'build-home'), 'LANG': 'C.UTF-8', 'DEBIAN_FRONTEND': 'noninteractive',
                            'NEEDRESTART_MODE': 'l'}
        self.activated = False

    def publish(self, completed: int, message: str, state: str = 'running', error: str | None = None) -> None:
        """Report completed stages, never a fabricated duration-based percentage."""
        self.status.update(state=state, completedSteps=completed, stage=STAGES[min(completed, 11)],
                           updatedAt=int(time.time() * 1000), error=error)
        self.status['log'] = (self.status['log'] + [message])[-80:]
        atomic_json(self.operation / 'status.json', self.status, 0o644)

    def cancelled(self) -> bool:
        """The SSH account can request cancellation without acquiring runtime root."""
        with (self.operation / 'cancel').open('rb') as source:
            return source.read(1) == b'1'

    def run(self, argv: list[str], *, user: str | None = None, input_data: bytes | None = None, timeout: int = 900, env: dict | None = None) -> None:
        """Execute fixed argv only; raw command output never enters desktop logs."""
        if self.cancelled():
            raise InterruptedError('Setup cancellation requested')
        command = ['/usr/sbin/runuser', '--preserve-environment', '-u', user, '--', *argv] if user else argv
        with (self.operation / 'command.log').open('wb') as log:
            process = subprocess.Popen(command, cwd=self.release, env=env or self.environment,
                                       stdin=subprocess.PIPE if input_data is not None else subprocess.DEVNULL,
                                       stdout=log, stderr=log, start_new_session=True)
            try:
                if input_data is not None:
                    process.stdin.write(input_data)
                    process.stdin.close()
                deadline = time.monotonic() + timeout
                while process.poll() is None:
                    if self.cancelled() or time.monotonic() >= deadline:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        raise InterruptedError('Command cancelled or timed out; inspect the operation before retrying')
                    if log.tell() > 4 * 1024 * 1024:
                        log.seek(0)
                        log.truncate()
                    time.sleep(0.25)
                if process.returncode:
                    raise RuntimeError(f'Setup command failed (exit {process.returncode}); root-only command.log contains diagnostics')
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()

    def download(self, url: str, digest: str, destination: Path) -> None:
        """Download an exact trusted artifact; never execute an unchecked response."""
        if not url.startswith('https://') or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise ValueError('Invalid pinned artifact')
        checksum = hashlib.sha256()
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url, timeout=30) as response, destination.open('wb') as output:
            size = 0
            while chunk := response.read(1024 * 1024):
                if self.cancelled():
                    raise InterruptedError('Download cancelled')
                size += len(chunk)
                if size > 256 * 1024 * 1024:
                    raise ValueError('Artifact exceeds download bound')
                output.write(chunk)
                checksum.update(chunk)
        if checksum.hexdigest() != digest:
            raise ValueError('Pinned artifact checksum mismatch')

    def preflight(self) -> None:
        """Recheck conflicts under the installation lock, not only during UI discovery."""
        metadata = dict(line.split('=', 1) for line in Path('/etc/os-release').read_text().splitlines() if '=' in line)
        if metadata.get('ID', '').strip('"') != 'ubuntu' or platform.machine() != 'x86_64' or not Path('/run/systemd/system').is_dir():
            raise ValueError('This installer requires Ubuntu x86_64 with systemd')
        if int(metadata.get('VERSION_ID', '"0"').strip('"').split('.')[0]) < 24:
            raise ValueError('Ubuntu 24.04 or later is required')
        if shutil.disk_usage('/var/lib').free < 10 * 1024 ** 3 or shutil.disk_usage('/opt').free < 5 * 1024 ** 3:
            raise ValueError('Insufficient disk space on installation volumes')
        memory = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemTotal:'))
        if memory < (3 if self.request['browser'] else 2) * 1024 ** 3:
            raise ValueError('Insufficient usable RAM: 2 GiB required, or 3 GiB with the browser runtime')
        for path in (PREFIX, DATA, CONFIG, *(UNIT_DIRECTORY / name for name in UNITS)):
            if path.exists() or path.is_symlink():
                raise ValueError('Native installation paths already exist; reuse or recovery review is required')
        signals = ('/etc/rancher/k3s', '/var/lib/kubelet', '/etc/kubernetes', '/var/lib/docker', '/var/lib/containerd', '/srv/remotejobs/pi-workspace', '/opt/outpost', '/var/lib/outpost')
        if any(Path(path).exists() for path in signals) and not self.request['coexistence']:
            raise ValueError('Existing deployment requires explicit independent-installation consent')
        if Path('/.dockerenv').exists() or Path('/run/.containerenv').exists():
            raise ValueError('Install on the host, not inside a container')
        for port in (4518, 4520):
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', port))
        for name in ('outpost-coord', 'outpost-pi', 'outpost-build'):
            try:
                pwd.getpwnam(name)
            except KeyError:
                continue
            raise ValueError('Dedicated service account already exists; review before installation')

    def accounts(self) -> None:
        """Create separate identities without sudo rules or privileged runtime grants."""
        PREFIX.mkdir(mode=0o755)
        (PREFIX / 'releases').mkdir(mode=0o755)
        DATA.mkdir(mode=0o711)
        CONFIG.mkdir(mode=0o755)
        self.release.mkdir(mode=0o755)
        for path, mode in ((PREFIX, 0o755), (PREFIX / 'releases', 0o755), (DATA, 0o711), (CONFIG, 0o755), (self.release, 0o755)):
            path.chmod(mode)
        self.run(['/usr/sbin/groupadd', '--system', 'outpost-workspaces'])
        for user in ('outpost-coord', 'outpost-pi', 'outpost-build'):
            self.run(['/usr/sbin/useradd', '--system', '--user-group', '--no-create-home', '--home-dir', '/nonexistent', '--shell', '/usr/sbin/nologin', user])
        for user in ('outpost-coord', 'outpost-pi'):
            self.run(['/usr/sbin/usermod', '--append', '--groups', 'outpost-workspaces', user])
        for name, user in (('coordinator', 'outpost-coord'), ('worker', 'outpost-pi')):
            path = DATA / name
            path.mkdir(mode=0o700)
            shutil.chown(path, user=user, group=user)
        shared = DATA / 'workspaces'
        shared.mkdir(mode=0o2770)
        shutil.chown(shared, user='outpost-coord', group='outpost-workspaces')
        shared.chmod(0o2770)
        home = self.operation / 'build-home'
        home.mkdir(mode=0o700)
        shutil.chown(home, user='outpost-build', group='outpost-build')
        shutil.copytree(self.operation / 'source', self.release, dirs_exist_ok=True)

    def runtime(self) -> None:
        """Install pinned private Node without changing host Node or package sources."""
        pins = json.loads((self.release / 'deploy/environment/runtime-pins.json').read_text())
        archive = self.operation / 'node.tar.xz'
        self.download(pins['nodeUrl'], pins['nodeSha256'], archive)
        with tarfile.open(archive) as source:
            source.extractall(self.release, filter='data')
        (self.release / f"node-v{pins['nodeVersion']}-linux-x64").rename(self.release / 'node')

    def dependencies(self) -> None:
        """Install lockfile-integrity checked dependencies as an unprivileged build user."""
        self.run(['/bin/chown', '-R', 'outpost-build:outpost-build', str(self.release)])
        self.run([str(self.node), str(self.release / 'node/lib/node_modules/npm/bin/npm-cli.js'), 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], user='outpost-build', timeout=1200)
        self.run([str(self.node), str(self.release / 'node_modules/typescript/bin/tsc'), '--version'], user='outpost-build')

    def browsers(self) -> None:
        """Optionally provision Chromium and a locked private Browser Use Python environment."""
        if not self.request['browser']:
            return
        env = {**self.environment, 'PLAYWRIGHT_BROWSERS_PATH': str(self.release / 'browsers'),
               'UV_PYTHON_INSTALL_DIR': str(self.release / 'python'), 'UV_CACHE_DIR': str(self.operation / 'build-home/cache')}
        self.run([str(self.node), str(self.release / 'node_modules/playwright/cli.js'), 'install-deps', 'chromium'], timeout=900)
        self.run([str(self.node), str(self.release / 'node_modules/playwright/cli.js'), 'install', 'chromium'], user='outpost-build', env=env)
        pins = json.loads((self.release / 'deploy/environment/runtime-pins.json').read_text())
        wheel = self.operation / 'uv.whl'
        self.download(pins['uvUrl'], pins['uvSha256'], wheel)
        with zipfile.ZipFile(wheel) as source:
            name = next(name for name in source.namelist() if name.endswith('.data/scripts/uv'))
            uv = self.release / 'node/bin/uv'
            uv.write_bytes(source.read(name))
            uv.chmod(0o755)
        self.run([str(uv), 'sync', '--frozen', '--no-dev', '--project', str(self.release / 'server/browser-use'), '--python', pins['pythonVersion']], user='outpost-build', env=env, timeout=1200)

    def configuration(self) -> None:
        """Only the coordinator and worker receive their distinct protected configuration."""
        self.run(['/bin/chown', '-R', 'root:root', str(self.release)])
        self.run(['/bin/chmod', '-R', 'a+rX,go-w', str(self.release)])
        profile = DATA / 'worker/profile'
        atomic_json(self.release / 'pi-release.json', {'id': self.request['releaseId'], 'piVersion': json.loads((self.release / 'package.json').read_text())['dependencies']['@earendil-works/pi-coding-agent'],
                    'lockHash': hashlib.sha256((self.release / 'package-lock.json').read_bytes()).hexdigest(), 'profile': str(profile)}, 0o644)
        token = secrets.token_hex(32)
        for user, name in (('outpost-coord', 'coordinator'), ('outpost-pi', 'worker')):
            path = CONFIG / name
            path.mkdir(mode=0o700)
            shutil.chown(path, user=user, group=user)
            secret = path / 'worker-token'
            secret.write_text(token)
            secret.chmod(0o600)
            shutil.chown(secret, user=user, group=user)
        worker = {'PI_CODING_AGENT_DIR': str(profile), 'OUTPOST_PI_RELEASE_FILE': str(self.release / 'pi-release.json'),
                  'OUTPOST_PI_WORKSPACES': str(DATA / 'workspaces'), 'OUTPOST_PI_SESSIONS': str(DATA / 'worker/sessions'),
                  'OUTPOST_PI_WORKER_TOKEN_FILE': str(CONFIG / 'worker/worker-token'), 'OUTPOST_PI_WORKER_PORT': '4520', 'OUTPOST_WORKSPACE_SHARED': 'true'}
        coordinator = {'OUTPOST_DATA': str(DATA / 'coordinator'), 'OUTPOST_WORKSPACE_ROOT': str(DATA / 'workspaces'),
                       'OUTPOST_PI_WORKER_URL': 'http://127.0.0.1:4520', 'OUTPOST_PI_WORKER_TOKEN_FILE': str(CONFIG / 'coordinator/worker-token'),
                       'PORT': '4518', 'OUTPOST_ENVIRONMENT_LABEL': self.request['label'], 'OUTPOST_RUNTIME_RELEASE': self.request['releaseId'],
                       'OUTPOST_ALLOW_LEGACY_PROTOCOL': 'false', 'OUTPOST_EXECUTABLES': '/bin/ls:/usr/bin/id:/usr/bin/uname:/usr/bin/git'}
        if self.request['browser']:
            coordinator.update(OUTPOST_BROWSER_ENABLED='true', OUTPOST_BROWSER_PYTHON=str(self.release / 'server/browser-use/.venv/bin/python'),
                               PLAYWRIGHT_BROWSERS_PATH=str(self.release / 'browsers'))
        for name, values in (('worker', worker), ('coordinator', coordinator)):
            # Quoted systemd environment syntax; reject control characters in reviewed input.
            text = ''.join(key + '=' + json.dumps(value, ensure_ascii=False) + '\n' for key, value in values.items())
            path = CONFIG / (name + '.env')
            path.write_text(text)
            path.chmod(0o600)  # systemd reads these as root, not as the service account.
        (PREFIX / 'current').symlink_to(self.release)

    def enroll(self) -> None:
        """Pre-enroll the installing device without exposing a reusable bootstrap token."""
        public = {key: self.request[key] for key in ('environmentId', 'deviceId', 'publicKey')}
        public['name'] = 'Outpost Desktop'
        self.run([str(self.node), '--import', 'tsx', str(self.release / 'server/environment/initialize.ts')], user='outpost-coord',
                 input_data=json.dumps(public).encode(), env={**self.environment, 'HOME': str(DATA / 'coordinator'), 'OUTPOST_DATA': str(DATA / 'coordinator')})

    def services(self) -> None:
        """Enable persistent non-root units; no new root broker or sudo capability."""
        for name, user, source, private in (('worker', 'outpost-pi', 'server/pi-worker/main.ts', 'worker'), ('coordinator', 'outpost-coord', 'server/main.ts', 'coordinator')):
            after = 'After=network-online.target\nWants=network-online.target\n'
            if name == 'coordinator':
                after += 'After=outpost-native-worker.service\nRequires=outpost-native-worker.service\n'
            unit = '[Unit]\nDescription=Outpost native ' + name + '\n' + after + '[Service]\nType=simple\n'
            unit += f'User={user}\nGroup={user}\nSupplementaryGroups=outpost-workspaces\nUMask=0007\n'
            unit += f'WorkingDirectory={self.release}\nEnvironmentFile={CONFIG}/{name}.env\n'
            unit += f'Environment="PATH={self.release}/node/bin:/usr/bin:/bin" "HOME={DATA}/{private}"\n'
            unit += f'ExecStart={self.node} --import tsx {self.release}/{source}\n'
            unit += 'Restart=on-failure\nRestartSec=3\nTimeoutStopSec=30\nNoNewPrivileges=yes\nPrivateTmp=yes\nProtectSystem=strict\nProtectHome=yes\n'
            unit += f'ReadWritePaths={DATA}/{private} {DATA}/workspaces\n'
            unit += 'TasksMax=512\nLimitNOFILE=8192\nMemoryHigh=30%\nMemoryMax=40%\nCPUQuota=200%\n[Install]\nWantedBy=multi-user.target\n'
            path = UNIT_DIRECTORY / f'outpost-native-{name}.service'
            with path.open('x') as output:
                output.write(unit)
            path.chmod(0o644)
        self.run(['/usr/bin/systemd-analyze', 'verify', *(str(UNIT_DIRECTORY / name) for name in UNITS)])
        self.run(['/usr/bin/systemctl', 'daemon-reload'])
        self.activated = True
        self.run(['/usr/bin/systemctl', 'enable', '--now', *UNITS], timeout=60)

    def health(self) -> None:
        """Require both services and the expected newly enrolled environment identity."""
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        expected = self.request['environmentId']
        for _ in range(60):
            if self.cancelled():
                raise InterruptedError('Verification cancelled')
            try:
                with opener.open('http://127.0.0.1:4518/v2/environment', timeout=2) as response:
                    value = json.loads(response.read(32768))
                    if not isinstance(value, dict) or value.get('environmentId') != expected or value.get('protocolVersion') != 2 or value.get('runtime', {}).get('release') != self.request['releaseId'] or response.headers.get('x-outpost-environment-id') != expected:
                        raise ValueError('Installation identity mismatch')
                token = (CONFIG / 'coordinator/worker-token').read_text()
                request = urllib.request.Request('http://127.0.0.1:4520/v1', data=json.dumps({'type': 'management', 'owner': self.request['deviceId'], 'request': {'type': 'catalogue'}}).encode(), headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'})
                with opener.open(request, timeout=2) as response:
                    response.read(32768)
                self.run(['/usr/bin/systemctl', 'is-active', '--quiet', *UNITS], timeout=10)
                atomic_json(CONFIG / 'installation.json', {'schema': 1, 'layoutVersion': 1, 'environmentId': expected, 'release': self.request['releaseId'], 'apiPort': 4518, 'operationId': self.request['operationId']}, 0o644)
                return
            except (OSError, json.JSONDecodeError) as error:
                if isinstance(error, urllib.error.HTTPError):
                    error.close()
                time.sleep(1)
        raise RuntimeError('Services did not become ready; original installations are unchanged')

    def execute(self) -> None:
        """Run once, recording partial failure without deleting user data or retrying effects."""
        completed = 0
        try:
            with (OPERATIONS.parent / 'install.lock').open('w') as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                for step in (self.preflight, self.accounts, self.runtime, self.dependencies, self.browsers, self.configuration, self.enroll, self.services, self.health):
                    self.publish(completed, STAGES[completed] + ' started.')
                    if self.cancelled():
                        raise InterruptedError('Setup cancelled')
                    step()
                    completed += 1
                    self.publish(completed, STAGES[completed - 1] + ' completed.')
                self.publish(10, 'Server ready. Connect and verify this Mac before setup is complete.', 'ready')
        except (OSError, ValueError, RuntimeError, KeyError, StopIteration, tarfile.TarError, zipfile.BadZipFile, subprocess.SubprocessError) as error:
            if self.activated:
                # Only this fresh installation's units; no legacy service or data is touched.
                subprocess.run(['/usr/bin/systemctl', 'disable', '--now', *UNITS], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=45, check=False)
            self.publish(completed, 'Setup stopped. Partial native files are retained for review; existing deployments were not changed.',
                         'cancelled' if isinstance(error, InterruptedError) else 'failed', str(error)[:400])


if __name__ == '__main__':
    if sys.argv[1:] == ['--bootstrap']:
        bootstrap()
    elif len(sys.argv) == 3 and sys.argv[1] == '--run' and os.geteuid() == 0:
        operation_path = Path(sys.argv[2])
        if operation_path.parent != OPERATIONS or str(uuid.UUID(operation_path.name)) != operation_path.name:
            raise ValueError('Invalid operation directory')
        Installer(operation_path).execute()
    else:
        raise SystemExit('Use the reviewed native setup protocol')
