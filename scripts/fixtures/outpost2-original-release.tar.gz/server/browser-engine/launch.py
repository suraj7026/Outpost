"""Emit local launch settings for the coordinator-owned Camoufox process."""
from __future__ import annotations

import contextlib
import json
import sys
from pathlib import Path

from camoufox.addons import DefaultAddons
from camoufox.pkgman import selected_launch_path
from camoufox.utils import launch_options

BROWSER_VERSION = "official/158.0.1-beta.41"


def main() -> None:
    """Resolve only the pinned installed build; never download during a task."""
    with contextlib.redirect_stdout(sys.stderr):
        executable = selected_launch_path(BROWSER_VERSION)
        options = launch_options(
            executable_path=executable,
            headless=True,
            os={"darwin": "macos", "linux": "linux", "win32": "windows"}[sys.platform],
            enable_cache=True,
            exclude_addons=list(DefaultAddons),
            humanize=False,
            env={},
        )
    if not Path(executable).is_file():
        raise RuntimeError("The pinned Camoufox browser is not installed")
    # Never pass the coordinator's credentials into a browser process.
    options["env"] = {
        key: str(value) for key, value in options["env"].items()
        if key.startswith("CAMOU_") or key.startswith("FONTCONFIG_")
    }
    print(json.dumps(options))


if __name__ == "__main__":
    main()
