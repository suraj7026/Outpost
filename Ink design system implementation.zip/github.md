repo: suraj7026/Outpost
branch: main

## Last sync
date: 2026-09-25T00:00:00Z

### Updated in this project
- Repository linked; not used as a source yet (early scaffolding, per user)
- Screens built from the written brief with the Graphite / Ink system

## Screen map
| Screen | Repo files |
|---|---|
| All screens | none yet |
